export function isLastRowVisible(tableId) {
    const table = document.getElementById(tableId);
    if (!table) return false;
    
    const lastRow = table.rows[table.rows.length - 1];
    if (!lastRow) return false;
    
    const rect = lastRow.getBoundingClientRect();
    return (
        rect.top >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight)
    );
}